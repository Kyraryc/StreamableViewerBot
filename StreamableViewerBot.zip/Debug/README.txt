****************
Streamable viewer bot
Written by: Kyraryc
****************

***Overview***

This bot is designed to parse through a respect thread or go through a list of links, and check every link to make sure they haven't been removed.  It will open an internet explorer browser and navigate to each link.

*****************

***How to use***

Step 1.)  Make sure that "config.txt" is in the same location as the app.  If it isn't, go download it from github or make your own (details later)

Step 2.)  If you are planning on parsing a respect thread, make sure that "threads.txt" is in the same location as the app.  It should contain a list of every single reddit respect thread that you want searched.

3.)  If you are planning on on parsing through a list, make sure that "links.txt" is in the same location as the app.  It should contain a list of links and an identifier for each seperated with a tab.

4.)  Open up the app.

5.)  Click the big button.

6.)  Mute your computer and ignore for awhile.  This can take awhile.

7.)  Once it reaches the end, close.  You'll know it's reached the end when one link doesn't change anymore.

8.)  Open up the "output.txt" file and look at the results.

**********************

***Supported links***

Due to the large number of hosting sites, only a few are checked.  Imgur, Streamable, and Gfycat are currently supported.

***********************

***Config file***

Config.txt controls the specifics.  It should have the following 8 columns specifically in this order:

	1.)  Mode (Thread/Link/Subview)
To parse through a respect thread, use "Thread".  If you already have a list of links to check, use "Link."  To use this to farm views on at risk streamables, ues "Subview."

	2.)  Fullplay (True/False)
This will determine whether to let a streamable video play completely or not.  Recommened setting is "False", as large number of videos can take quite awhile.

	3.)  Loop (True/False)
Used in conjuction with Start (Later).  Basically, the bot is set up to be able to start anywhere in the list provided.  This setting determines what to do when it reaches the end of the input file in such cases.  If True, the bot will go back to the beginning and work its way until it reaches the start index.

	4.) Count (True/False)
Reporting setting.  Used to determine whether or not to report the total number of links checked.

	5.) Time (True False)
Reporting setting.  Used to determine whehter or not to report the total amount of time taken to check every link.

	6.)  MakeList (url)
Used to determine whether or not to create a list of every single link checked.  If you want it to, simply enter the main url.  If not, simply leave it blank.  For instance, if you enter "streamable", the bot will create a list of all streamable links checked.  It will be saved as "links.txt"

	7.)  Sub (#)
Used to create a streamable specific list of any video with fewer views than the number specified.  Will be saved as "Subview.txt"

	8.)  Start (url)
Used to start from a specific respect thread or link.

*************************

***Misc***

1.)  Sometimes, IE crashes.  In this case, the bot will open up a new IE browser.  It will close any other existing IE browser, so be careful.

2.)  NSFW threads sometimes don't work right.  Best thing to do would be to temporarily remove the NSFW and or spoiler tag and redo the thread.

3.)  Ignore that it doesn't look pretty.  I'm not even trying.